package com.example.appcoffee.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.appcoffee.MainActivity;
import com.example.appcoffee.R;
import com.google.firebase.auth.FirebaseAuth;


public class SplashScreen extends AppCompatActivity {

    ProgressBar progressBar;
    FirebaseAuth auth;

    // Задержка времени отображения сплэш-экрана в миллисекундах
    private static final int SPLASH_SCREEN_DELAY = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);


        // Используем Handler для отображения сплэш-экрана в течение заданной задержки
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                auth = FirebaseAuth.getInstance();
                progressBar = findViewById(R.id.progressbar);
                progressBar.setVisibility(View.GONE);

                if(auth.getCurrentUser() != null){
                    progressBar.setVisibility(View.VISIBLE);
                    startActivity(new Intent(SplashScreen.this, MainActivity.class));
                    finish();
                } else {
                    // По истечении времени задержки, запускаем основную активность приложения
                    Intent intent = new Intent(SplashScreen.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, SPLASH_SCREEN_DELAY);
    }
}
